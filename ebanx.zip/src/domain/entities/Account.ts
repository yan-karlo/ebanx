export class Account {
  constructor(public readonly id: string, public balance: number = 0) { }
}