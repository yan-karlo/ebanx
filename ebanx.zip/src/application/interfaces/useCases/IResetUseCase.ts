export interface IResetUseCase {
  run(): Promise<void>;
}